#!/bin/bash

cd ../../../target
exec java -jar virtual-smart-city-client-1.0-SNAPSHOT-jar-with-dependencies.jar -i asd


